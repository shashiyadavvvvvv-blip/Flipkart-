import MarketplaceApp from './MarketplaceApp'

export default function App() {
  return <MarketplaceApp />
}
